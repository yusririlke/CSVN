This character portrait pack is licensed under a Attribution 4.0 International (CC BY 4.0) 5/29/2022.

You may use the character portraits in this pack for personal and commercial projects so long as the sprite themselves are not sold commercially whether individually, in packs, or as part of character generators. 
Use of these sprites in character generators within commerical games is acceptable.

Part of the art included in this pack has been modified from Sutemo's "Male Character Sprite for Visual Novel" found on https://sutemo.itch.io/male-character-sprite-for-visual-novel.
When using these assets the artists should be credited using the artist name 'J. Claudee' or 'JClaudee (Sraye)' and Sutemo or Stereo-mono.

As a courtesy, if using this work commercially, please inform the artist(s) of where the work will be used by contacting the artist on itch.io. 
A lack of reply does not indicate lack of permission and the assets may be used as specified by the license.

The artwork in this pack may be altered, traced, and used commercially in games, comics, and other transformative projects.

Included in This Pack:
1 PSD File (1100x1300)

Future artwork for non-commercial and commercial projects can be commissioned directly from the artist.
deviantart: https://www.deviantart.com/jclaudee
itch.io: https://sraye.itch.io